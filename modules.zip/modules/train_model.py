import tensorflow as tf

import numpy as np
import glob
import io
import os
import math
if __name__ == "__main__":
  #------------------------------DATA-------------------------------------------
  working_dir = "dataSet"
  firstSample = True
  data_x = None
  data_x_train = None
  data_x_test = None
  ratio = 0.8
  data_y = None
  data_y_train = None
  data_y_test = None
  gestureOrder = list()
  gestureNum = 0
  channelsEMG = 8
  gesturesTotal = 0
  numberOfStepsPerSample = 0
  myList = list()
  for path in glob.glob(os.path.join(working_dir,"*.txt")):
    with io.open(path, mode="r", encoding="utf-8") as fd:
      np_array_reshaped = None
      gesturesTotal +=1
      for line in fd:
        line = line[1:len(line)-2]
        line = line.replace(',','')
        line = line.split(" ")
        numLine = list(map(int,line))
        myList.append(numLine)
      if(firstSample):
        totalSamples = int((len(myList[0])/8))
        print("totalNumberOfExam", totalSamples)
        np_examples = np.empty((len(myList),totalSamples,8),int)
      for i in range(len(np_examples)):
        np_array = np.asarray(myList[i])
        np_array_reshaped = np_array.reshape(totalSamples,8)
        np_examples[i] = np_array_reshaped
      np_examples = tf.keras.utils.normalize(np_examples)
      y_label_Class = os.path.basename(fd.name)
      if(firstSample):
        data_x = np.copy(np_examples)
        data_x_train = np.copy(np_examples[0:int(len(np_examples)*ratio)])
        data_x_test = np.copy(np_examples[int(len(np_examples)*ratio):len(np_examples)])
        firstSample = False
      else:
        data_x = np.concatenate((data_x,np_examples),axis=0)
        data_x_train = np.concatenate((data_x_train,np_examples[0:int(len(np_examples)*ratio)]),axis=0)
        data_x_test = np.concatenate((data_x_test,np_examples[int(len(np_examples)*ratio):len(np_examples)]),axis=0)
      gestureOrder.append(y_label_Class)
      myList.clear()

  samplesPerGesture = int(len(data_x)/len(gestureOrder))
  data_y = list()
  data_y_train = list()
  data_y_test = list()
  label_text = open("label.txt","w+")
  for label in range(len(gestureOrder)):
    data_y = data_y + ([label] * samplesPerGesture)
    data_y_train = data_y_train + [label] * int(samplesPerGesture * ratio)
    if(ratio > 0.7):
      data_y_test = data_y_test + [label] * int(samplesPerGesture * (1 - ratio) + 1)
    else:
      data_y_test = data_y_test + [label] * int(samplesPerGesture * (1 - ratio) )
    print("Number: ", label, "is assigned to", gestureOrder[label])
    label_text.write(str(label) + "," + str(gestureOrder[label]) + "\r\n")
  label_text.close()
  data_y = np.asarray(data_y)
  data_y_train = np.asarray(data_y_train)
  data_y_test = np.asarray(data_y_test)
  data_y_train = tf.keras.utils.to_categorical(data_y_train)
  data_y_test = tf.keras.utils.to_categorical(data_y_test)
  #-----------------------------DATA--------------------------------------------
  #----------------LTSM NETWORK-------------------------------------------------
  EPOCHS = 10
  BATCH_SIZE = 32

  model_signal_emg = tf.keras.models.Sequential()
  model_signal_emg.add(tf.keras.layers.LSTM(128,
                                           input_shape=data_x_train.shape[-2:]))
  model_signal_emg.add(tf.keras.layers.Dense(128,activation='relu'))
  model_signal_emg.add(tf.keras.layers.Dense(gesturesTotal,activation = 'softmax'))

  model_signal_emg.compile(loss='categorical_crossentropy', optimizer='adam', metrics=['accuracy'])
  model_signal_emg.fit(data_x_train, data_y_train, epochs=EPOCHS, batch_size=BATCH_SIZE, verbose=1)
  _, accuracy = model_signal_emg.evaluate(data_x_test, data_y_test, batch_size=BATCH_SIZE, verbose=0)
  print("the accuracy of this model is:",accuracy)


  #----------------lite converter-----------------------------------------------
  numberOfStepsPerSample = data_x_train[0].shape[0]
  run_model = tf.function(lambda x: model_signal_emg(x))
  BATCH_SIZE = 1
  STEPS = numberOfStepsPerSample
  INPUT_SIZE = 8
  concrete_func = run_model.get_concrete_function(
    tf.TensorSpec([BATCH_SIZE, STEPS, INPUT_SIZE], model_signal_emg.inputs[0].dtype))


  model_signal_emg.save("saved_model/my_model2",save_format='tf',signatures=concrete_func)
  converter = tf.lite.TFLiteConverter.from_saved_model("saved_model/my_model2")
  tflite_model = converter.convert()
  with tf.io.gfile.GFile('<yourpath>/model.tflite','wb') as f:
    f.write(tflite_model)
